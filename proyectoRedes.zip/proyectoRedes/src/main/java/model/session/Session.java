package model.session;

public class Session {

    private String IP, Username, Password;


}
